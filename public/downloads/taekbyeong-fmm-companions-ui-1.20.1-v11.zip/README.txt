택병서버 Minecraft Java 1.20.1 필수 통합 리소스팩 v11

- FMM 동료 12종과 엔진 장애 시 ItemDisplay 대체 모델을 포함합니다.
- 본문 위에 겹치는 가변 표제판과 단일 클릭 밀랍 인장을 포함합니다.
- TAB 사이드바 점수 숫자를 숨기며 `minecraft:default` 폰트는 보존합니다.
- 이전 ModelEngine·BetterModel 플러그인은 필요하지 않습니다.
