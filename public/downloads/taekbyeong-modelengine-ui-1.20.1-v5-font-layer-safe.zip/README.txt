택병서버 Minecraft Java 1.20.1 전용 UI v4

- 고대 두루마리 공지용 `taekbyeong:scroll` 독립 폰트를 추가합니다.
- `minecraft:default` 폰트를 덮어쓰지 않아 기본 폰트 로딩을 보존합니다.

- TAB 사이드바 오른쪽의 빨간 점수 숫자를 화면 밖으로 이동합니다.
- 블록, 아이템, 글꼴 등 다른 리소스는 변경하지 않습니다.

Core shader 방식 참고:
https://github.com/McTsts/mc-core-shaders/tree/main/hide%20sidebar%20numbers
