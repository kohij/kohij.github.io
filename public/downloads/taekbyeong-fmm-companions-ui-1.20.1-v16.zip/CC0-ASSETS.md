# CC0 동료 원본 자산

택병서버 동료 12종은 아래 Quaternius 무료 자산을 Minecraft 큐브 모델로 변환·재채색한 파생물이다.

- 라이선스: CC0 1.0 Universal (`LICENSE-QUATERNIUS.txt`)
- 변환 도구: `tools/convert-quaternius-companions.py`
- 출력: `custom-models/companions/*.bbmodel`

| 동료 모델 | 원본 파일 | 원본 팩 |
|---|---|---|
| `tb_clockwork_sprite` | `brass_fairy_bee.gltf` (Bee) | [Cute Animated Monsters](https://quaternius.com/packs/cutemonsters.html) |
| `tb_osmium_hound` | `osmium_hound_husky.gltf` (Husky) | [Ultimate Animated Animal Pack](https://quaternius.com/packs/ultimateanimatedanimals.html) |
| `tb_void_lynx` | `void_cat.gltf` (Blob Cat) | [Ultimate Monsters](https://quaternius.com/packs/ultimatemonsters.html) |
| `tb_rescue_drone` | `rescue_drone_goleling_evolved.gltf` | [Ultimate Monsters](https://quaternius.com/packs/ultimatemonsters.html) |
| `tb_fluix_spirit` | `fluix_spirit_ghost.gltf` | [Cute Animated Monsters](https://quaternius.com/packs/cutemonsters.html) |
| `tb_corsair_wing` | `pirate_parrot_birb.gltf` | [Ultimate Monsters](https://quaternius.com/packs/ultimatemonsters.html) |
| `tb_glitch_puffer` | `puffer.obj` | [Animated Cute Fish Pack](https://quaternius.com/packs/animatedcutefish.html) |
| `tb_tide_drake` | `dragon_axolotl_yellow_dragon.gltf` | [Cute Animated Monsters](https://quaternius.com/packs/cutemonsters.html) |
| `tb_honey_blob` | `honey_slime_green_blob.gltf` | [Ultimate Monsters](https://quaternius.com/packs/ultimatemonsters.html) |
| `tb_reactor_firefly` | `reactor_firefly_armabee_evolved.gltf` | [Ultimate Monsters](https://quaternius.com/packs/ultimatemonsters.html) |
| `tb_frost_fox` | `snow_fox.gltf` (Fox) | [Ultimate Animated Animal Pack](https://quaternius.com/packs/ultimateanimatedanimals.html) |
| `tb_singularity_watcher` | `singularity_watcher_cyclops.gltf` | [Cute Animated Monsters](https://quaternius.com/packs/cutemonsters.html) |

원본 팩 페이지 모두 무료 개인·상업 사용과 CC0를 명시한다. 배포물에는 출처 투명성을 위해 이 문서와 원본 라이선스를 유지한다.
