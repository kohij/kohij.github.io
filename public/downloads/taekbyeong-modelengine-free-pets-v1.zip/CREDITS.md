# 택병서버 무료 ModelEngine 에셋

`blueprints/taekbyeong/tb_*.bbmodel` 4종은 Microsoft의 `minecraft-samples`
Custom Cat Eliza 모델을 색상 변형한 것입니다.

- 원본: https://github.com/microsoft/minecraft-samples/tree/16058e51ad5e79ab3c1fa8e930b803385a5dd2e5/casual_creator/custom_cat_eliza
- 고정 커밋: `16058e51ad5e79ab3c1fa8e930b803385a5dd2e5`
- 라이선스: MIT
- 저작권: Microsoft Corporation
- 변경: 모델 ID, 텍스처 팔레트, 파일명

## MIT License

Copyright (c) Microsoft Corporation.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

나머지 8종은 대응 모델이 없으면 서버 자체 바닐라 외형으로 안전하게 폴백합니다.
