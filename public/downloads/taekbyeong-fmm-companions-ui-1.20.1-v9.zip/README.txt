택병서버 Minecraft Java 1.20.1 필수 통합 리소스팩 v7

- 외부 엔진 없는 자체 ItemDisplay 동료 12종 모델과 텍스처를 포함합니다.
- 고대 두루마리 공지용 `taekbyeong:scroll` 독립 폰트를 포함합니다.
- TAB 사이드바 점수 숫자를 숨기며 `minecraft:default` 폰트는 보존합니다.
- 이전 ModelEngine·BetterModel 플러그인은 필요하지 않습니다.
