택병서버 Minecraft Java 1.20.1 전용 UI 정리팩

- TAB 사이드바 오른쪽의 빨간 점수 숫자를 화면 밖으로 이동합니다.
- 블록, 아이템, 글꼴 등 다른 리소스는 변경하지 않습니다.

Core shader 방식 참고:
https://github.com/McTsts/mc-core-shaders/tree/main/hide%20sidebar%20numbers
